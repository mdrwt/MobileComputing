package in.ac.iiitd.mt14033.passwordmanager;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

/**
 * Created by veronica on 20/10/16.
 */

public class AdvancedSetttingsActivity extends AppCompatActivity{

    private static final String TAG = "mt14033.PM.AdvancedSettingsAct";

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_advanced_settings);
    }
}
